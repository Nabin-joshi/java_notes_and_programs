import java.io.File;
import java.io.InputStream;
import java.util.Scanner;

public class io {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String Name = sc.nextLine();
        System.out.println(Name);
    }
}
